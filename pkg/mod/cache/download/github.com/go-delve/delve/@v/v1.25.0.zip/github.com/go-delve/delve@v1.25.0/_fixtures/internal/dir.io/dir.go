package dirio

type SomeType struct {
	X int
}

var A string = "something"

func SomeFunction() {
	println("hello world")
}
